// Minimal Express + Socket.IO backend for realtime updates
const express = require('express');
const http = require('http');
const path = require('path');
const fs = require('fs');
const socketio = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = socketio(server, { cors: { origin: "*" } });

const PORT = process.env.PORT || 3000;

// Serve static files (frontend) from project root (one level up from /backend)
app.use('/', express.static(path.join(__dirname, '..')));

// Simple API endpoint for places
app.get('/api/places', (req, res) => {
  try {
    const places = JSON.parse(fs.readFileSync(path.join(__dirname, 'places.json'), 'utf8'));
    res.json(places);
  } catch (e) {
    res.status(500).json({ error: 'Failed to load places' });
  }
});

// Track connected users
let onlineCount = 0;

io.on('connection', (socket) => {
  onlineCount++;
  io.emit('onlineCount', onlineCount);

  socket.on('disconnect', () => {
    onlineCount--;
    io.emit('onlineCount', onlineCount);
  });

  // Admin can broadcast a new deal
  socket.on('newDeal', (deal) => {
    // Basic sanitization & shape
    const safe = {
      title: String(deal.title || 'Special Offer'),
      description: String(deal.description || ''),
      expiresAt: String(deal.expiresAt || ''),
    };
    io.emit('deal', safe);
  });
});

server.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});